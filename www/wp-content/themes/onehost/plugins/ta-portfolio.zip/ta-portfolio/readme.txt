=== TA Portfolio Management ===
Contributors: ThemeAlien
Tags: developer, development, local
Requires at least: 3.1
Tested up to: 3.9.2
Stable tag: 1.0.2

This plugin help you create and manage portfolio projects.
It provide shortcode generator UI to help you build unique portfolio showcase.

== Description ==

This plugin help you create and manage portfolio projects.
It provide shortcode generator UI to help you build unique portfolio showcase.

This plugin provide many hooks to help developers improve it or just make it be suitable with their themes.

== Installation ==

1. Unzip the package and upload to your plugins directory.
1. Log into WordPress and navigate to the "Plugins" screen.
1. Locate "TA Portfolio Management" in the list and click the "Activate" link. Done.

== Changelog ==

= 1.0.2 =
First stable version
